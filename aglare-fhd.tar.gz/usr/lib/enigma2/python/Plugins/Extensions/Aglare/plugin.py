# -*- coding: utf-8 -*-
# mod by Lululla

from Components.ActionMap import ActionMap
from Components.config import (
    config,
    ConfigSubsection,
    getConfigListEntry,
    ConfigEnableDisable,
    ConfigSelectionNumber,
    ConfigClock,
    ConfigSelection,
)
from Components.ConfigList import ConfigListScreen
# from Components.Sources.Progress import Progress
# from Tools.Downloader import downloadWithProgress
# from Components.Sources.StaticText import StaticText
# from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.AVSwitch import AVSwitch
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.Standby import TryQuitMainloop
from Tools.Directories import fileExists
# from datetime import datetime
from enigma import ePicLoad, eTimer
import os
import sys
import time


PY3 = sys.version_info.major >= 3
if PY3:
    bytes = bytes
    unicode = str
    from urllib.request import urlopen
    from urllib.request import Request

else:
    from urllib2 import urlopen
    from urllib2 import Request


global versionaglare
versionaglare = '4.0'


config.plugins.Aglare = ConfigSubsection()

config.plugins.Aglare.autoupdate = ConfigEnableDisable(default=True)
config.plugins.Aglare.timetype = ConfigSelection(default="interval", choices=[("interval", _("interval")), ("fixed time", _("fixed time"))])
config.plugins.Aglare.updateinterval = ConfigSelectionNumber(default=60, min=5, max=86400, stepwidth=5)
config.plugins.Aglare.fixedtime = ConfigClock(default=46800)

config.plugins.Aglare.colorSelector = ConfigSelection(default='head', choices=[
    ('head', _('Default')),
    ('color1', _('Black')),
    ('color2', _('Brown')),
    ('color3', _('Green')),
    ('color4', _('Magenta')),
    ('color5', _('Blue')),
    ('color6', _('Red')),
    ('color7', _('Purple'))])
config.plugins.Aglare.FontStyle = ConfigSelection(default='basic', choices=[
    ('basic', _('Default')),
    ('font1', _('HandelGotD')),
    ('font2', _('KhalidArtboldRegular')),
    ('font3', _('BebasNeue')),
    ('font4', _('Greta'))])
config.plugins.Aglare.skinSelector = ConfigSelection(default='base', choices=[
    ('base', _('Default'))])
config.plugins.Aglare.InfobarStyle = ConfigSelection(default='infobar_base1', choices=[
    ('infobar_base1', _('Default'))])
config.plugins.Aglare.InfobarPosterx = ConfigSelection(default='infobar_posters_posterx_off', choices=[
    ('infobar_posters_posterx_off', _('OFF')),
    ('infobar_posters_posterx_on', _('ON'))])
config.plugins.Aglare.InfobarXtraevent = ConfigSelection(default='infobar_posters_xtraevent_off', choices=[
    ('infobar_posters_xtraevent_off', _('OFF')),
    ('infobar_posters_xtraevent_on', _('ON')),
    ('infobar_posters_xtraevent_info', _('Backdrop'))])
config.plugins.Aglare.InfobarDate = ConfigSelection(default='infobar_no_date', choices=[
    ('infobar_no_date', _('Infobar_NO_Date')),
    ('infobar_date', _('Infobar_Date'))])
config.plugins.Aglare.InfobarWeather = ConfigSelection(default='infobar_no_weather', choices=[
    ('infobar_no_weather', _('Infobar_NO_Weather')),
    ('infobar_weather', _('Infobar_Weather'))])
config.plugins.Aglare.SecondInfobarStyle = ConfigSelection(default='secondinfobar_base1', choices=[
    ('secondinfobar_base1', _('Default'))])
config.plugins.Aglare.SecondInfobarPosterx = ConfigSelection(default='secondinfobar_posters_posterx_off', choices=[
    ('secondinfobar_posters_posterx_off', _('OFF')),
    ('secondinfobar_posters_posterx_on', _('ON'))])
config.plugins.Aglare.SecondInfobarXtraevent = ConfigSelection(default='secondinfobar_posters_xtraevent_off', choices=[
    ('secondinfobar_posters_xtraevent_off', _('OFF')),
    ('secondinfobar_posters_xtraevent_on', _('ON'))])
config.plugins.Aglare.ChannSelector = ConfigSelection(default='channellist_no_posters', choices=[
    ('channellist_no_posters', _('ChannelSelection_NO_Posters')),
    ('channellist_no_posters_no_picon', _('ChannelSelection_NO_Posters_NO_Picon')),
    ('channellist_backdrop_v', _('ChannelSelection_BackDrop_V')),
    ('channellist_1_poster', _('ChannelSelection_1_Poster')),
    ('channellist_4_posters', _('ChannelSelection_4_Posters')),
    ('channellist_big_mini_tv', _('ChannelSelection_big_mini_tv'))])
config.plugins.Aglare.EventView = ConfigSelection(default='eventview_no_posters', choices=[
    ('eventview_no_posters', _('EventView_NO_Posters')),
    ('eventview_7_posters', _('EventView_7_Posters'))])

config.plugins.Aglare.VolumeBar = ConfigSelection(default='volume1', choices=[
    ('volume1', _('Default')),
    ('volume2', _('volume2'))])


class AglareSetup(ConfigListScreen, Screen):
    skin = '<screen name="AglareSetup" position="center,center" size="1000,640" title="Aglare-FHD Skin Controler">\n\t\t  <eLabel font="Regular; 24" foregroundColor="#00ff4A3C" halign="center" position="20,598" size="120,26" text="Cancel" />\n\t\t  <eLabel font="Regular; 24" foregroundColor="#0056C856" halign="center" position="220,598" size="120,26" text="Save" />\n\t\t  <eLabel font="Regular; 24" foregroundColor="#00fbff3c" halign="center" position="420,598" size="120,26" text="Update" />\n\t\t  <eLabel font="Regular; 24" foregroundColor="#00403cff" halign="center" position="620,598" size="120,26" text="Preview" />\n\t\t  <widget name="Preview" position="997,690" size="498, 280" zPosition="1" />\n\t\t <widget name="config" font="Regular; 24" itemHeight="40" position="5,5" scrollbarMode="showOnDemand" size="990,550" />\n\t\t\n\t\t  </screen>'

    def __init__(self, session):
        self.version = '.Aglare-FHD'
        Screen.__init__(self, session)
        self.session = session
        self.skinFile = '/usr/share/enigma2/Aglare-FHD/skin.xml'
        self.previewFiles = '/usr/lib/enigma2/python/Plugins/Extensions/Aglare/sample/'
        self['Preview'] = Pixmap()
        indent = "- "
        list = []
        list.append(getConfigListEntry(_("Scheduled Skin Update:"), config.plugins.Aglare.autoupdate, _("Active Automatic Skin Update")))
        if config.plugins.Aglare.autoupdate:  # .value is True:
            list.append(getConfigListEntry(indent + _("Schedule type:"), config.plugins.Aglare.timetype, _("At an interval of hours or at a fixed time")))
            if config.plugins.Aglare.timetype.value == "interval":
                list.append(getConfigListEntry(2 * indent + _("Update interval (minutes):"), config.plugins.Aglare.updateinterval, _("Configure every interval of minutes from now")))
            if config.plugins.Aglare.timetype.value == "fixed time":
                list.append(getConfigListEntry(2 * indent + _("Time to start update:"), cfg.fixedtime, _("Configure at a fixed time")))

        list.append(getConfigListEntry(_('Color Style:'), config.plugins.Aglare.colorSelector))
        list.append(getConfigListEntry(_('Select Your Font:'), config.plugins.Aglare.FontStyle))
        list.append(getConfigListEntry(_('Skin Style:'), config.plugins.Aglare.skinSelector))
        list.append(getConfigListEntry(_('InfoBar Style:'), config.plugins.Aglare.InfobarStyle))
        list.append(getConfigListEntry(_('InfoBar PosterX:'), config.plugins.Aglare.InfobarPosterx))
        list.append(getConfigListEntry(_('InfoBar Xtraevent:'), config.plugins.Aglare.InfobarXtraevent))
        list.append(getConfigListEntry(_('InfoBar Date:'), config.plugins.Aglare.InfobarDate))
        list.append(getConfigListEntry(_('InfoBar Weather:'), config.plugins.Aglare.InfobarWeather))
        list.append(getConfigListEntry(_('SecondInfobar Style:'), config.plugins.Aglare.SecondInfobarStyle))
        list.append(getConfigListEntry(_('SecondInfobar Posterx:'), config.plugins.Aglare.SecondInfobarPosterx))
        list.append(getConfigListEntry(_('SecondInfobar Xtraevent:'), config.plugins.Aglare.SecondInfobarXtraevent))
        list.append(getConfigListEntry(_('ChannelSelection Style:'), config.plugins.Aglare.ChannSelector))
        list.append(getConfigListEntry(_('EventView Style:'), config.plugins.Aglare.EventView))
        list.append(getConfigListEntry(_('VolumeBar Style:'), config.plugins.Aglare.VolumeBar))

        ConfigListScreen.__init__(self, list)
        self['actions'] = ActionMap(['OkCancelActions',
                                     'DirectionActions',
                                     'InputActions',
                                     'ColorActions'], {'left': self.keyLeft,
                                                       'down': self.keyDown,
                                                       'up': self.keyUp,
                                                       'right': self.keyRight,
                                                       'red': self.keyExit,
                                                       'green': self.keySave,
                                                       'yellow': self.checkforUpdate,
                                                       'blue': self.info,
                                                       'cancel': self.keyExit}, -1)
        self.PicLoad = ePicLoad()
        self.Scale = AVSwitch().getFramebufferScale()
        try:
            self.PicLoad.PictureData.get().append(self.DecodePicture)
        except:
            self.PicLoad_conn = self.PicLoad.PictureData.connect(self.DecodePicture)

        self.timer = eTimer()
        if os.path.exists('/var/lib/dpkg/status'):
            self.timer_conn = self.timer.timeout.connect(self.checkforUpdate)
        else:
            self.timer.callback.append(self.checkforUpdate)
        self.timer.start(500, 1)
        self.onLayoutFinish.append(self.UpdateComponents)

    def GetPicturePath(self):
        try:
            returnValue = self['config'].getCurrent()[1].value
            path = '/usr/lib/enigma2/python/Plugins/Extensions/Aglare/screens/' + returnValue + '.png'
            if fileExists(path):
                return path
            else:
                return '/usr/lib/enigma2/python/Plugins/Extensions/Aglare/screens/default.png'
        except:
            return '/usr/lib/enigma2/python/Plugins/Extensions/Aglare/screens/default.png'

    def UpdatePicture(self):
        self.PicLoad.PictureData.get().append(self.DecodePicture)
        self.onLayoutFinish.append(self.ShowPicture)

    def ShowPicture(self, data=None):
        if self["Preview"].instance:
            width = 498
            height = 280
            self.PicLoad.setPara([width, height, self.Scale[0], self.Scale[1], 0, 1, "ff000000"])
            if self.PicLoad.startDecode(self.GetPicturePath()):
                self.PicLoad = ePicLoad()
                try:
                    self.PicLoad.PictureData.get().append(self.DecodePicture)
                except:
                    self.PicLoad_conn = self.PicLoad.PictureData.connect(self.DecodePicture)
            return

    def DecodePicture(self, PicInfo=None):
        ptr = self.PicLoad.getData()
        if ptr is not None:
            self["Preview"].instance.setPixmap(ptr)
            self["Preview"].instance.show()
        return

    def UpdateComponents(self):
        self.UpdatePicture()

    def info(self):
        aboutbox = self.session.open(MessageBox, _('Setup Aglare for Aglare-FHD v.%s') % versionaglare, MessageBox.TYPE_INFO)
        aboutbox.setTitle(_('Info...'))

    def keyLeft(self):
        ConfigListScreen.keyLeft(self)
        self.ShowPicture()

    def keyRight(self):
        ConfigListScreen.keyRight(self)
        self.ShowPicture()

    def keyDown(self):
        self['config'].instance.moveSelection(self['config'].instance.moveDown)
        self.ShowPicture()

    def keyUp(self):
        self['config'].instance.moveSelection(self['config'].instance.moveUp)
        self.ShowPicture()

    def keySave(self):
        if not fileExists(self.skinFile + self.version):
            for x in self['config'].list:
                x[1].cancel()

            self.close()
            return
        for x in self['config'].list:
            x[1].save()

        try:
            skin_lines = []
            head_file = self.previewFiles + 'head-' + config.plugins.Aglare.colorSelector.value + '.xml'
            skFile = open(head_file, 'r')
            head_lines = skFile.readlines()
            skFile.close()
            for x in head_lines:
                skin_lines.append(x)

            font_file = self.previewFiles + 'font-' + config.plugins.Aglare.FontStyle.value + '.xml'
            skFile = open(font_file, 'r')
            font_lines = skFile.readlines()
            skFile.close()
            for x in font_lines:
                skin_lines.append(x)

            skn_file = self.previewFiles + 'infobar-' + config.plugins.Aglare.InfobarStyle.value + '.xml'
            skFile = open(skn_file, 'r')
            file_lines = skFile.readlines()
            skFile.close()
            for x in file_lines:
                skin_lines.append(x)

            skn_file = self.previewFiles + 'infobar-' + config.plugins.Aglare.InfobarPosterx.value + '.xml'
            skFile = open(skn_file, 'r')
            file_lines = skFile.readlines()
            skFile.close()
            for x in file_lines:
                skin_lines.append(x)

            skn_file = self.previewFiles + 'infobar-' + config.plugins.Aglare.InfobarXtraevent.value + '.xml'
            skFile = open(skn_file, 'r')
            file_lines = skFile.readlines()
            skFile.close()
            for x in file_lines:
                skin_lines.append(x)

            skn_file = self.previewFiles + 'infobar-' + config.plugins.Aglare.InfobarDate.value + '.xml'
            skFile = open(skn_file, 'r')
            file_lines = skFile.readlines()
            skFile.close()
            for x in file_lines:
                skin_lines.append(x)

            skn_file = self.previewFiles + 'infobar-' + config.plugins.Aglare.InfobarWeather.value + '.xml'
            skFile = open(skn_file, 'r')
            file_lines = skFile.readlines()
            skFile.close()
            for x in file_lines:
                skin_lines.append(x)

            skn_file = self.previewFiles + 'secondinfobar-' + config.plugins.Aglare.SecondInfobarStyle.value + '.xml'
            skFile = open(skn_file, 'r')
            file_lines = skFile.readlines()
            skFile.close()
            for x in file_lines:
                skin_lines.append(x)

            skn_file = self.previewFiles + 'secondinfobar-' + config.plugins.Aglare.SecondInfobarPosterx.value + '.xml'
            skFile = open(skn_file, 'r')
            file_lines = skFile.readlines()
            skFile.close()
            for x in file_lines:
                skin_lines.append(x)

            skn_file = self.previewFiles + 'secondinfobar-' + config.plugins.Aglare.SecondInfobarXtraevent.value + '.xml'
            skFile = open(skn_file, 'r')
            file_lines = skFile.readlines()
            skFile.close()
            for x in file_lines:
                skin_lines.append(x)

            skn_file = self.previewFiles + 'channellist-' + config.plugins.Aglare.ChannSelector.value + '.xml'
            skFile = open(skn_file, 'r')
            file_lines = skFile.readlines()
            skFile.close()
            for x in file_lines:
                skin_lines.append(x)

            skn_file = self.previewFiles + 'eventview-' + config.plugins.Aglare.EventView.value + '.xml'
            skFile = open(skn_file, 'r')
            file_lines = skFile.readlines()
            skFile.close()
            for x in file_lines:
                skin_lines.append(x)

            skn_file = self.previewFiles + 'vol-' + config.plugins.Aglare.VolumeBar.value + '.xml'
            skFile = open(skn_file, 'r')
            file_lines = skFile.readlines()
            skFile.close()
            for x in file_lines:
                skin_lines.append(x)

            base_file = self.previewFiles + 'base.xml'
            if config.plugins.Aglare.skinSelector.value == 'base1':
                base_file = self.previewFiles + 'base1.xml'
            if config.plugins.Aglare.skinSelector.value == 'base':
                base_file = self.previewFiles + 'base.xml'
            skFile = open(base_file, 'r')
            file_lines = skFile.readlines()
            skFile.close()
            for x in file_lines:
                skin_lines.append(x)

            xFile = open(self.skinFile, 'w')
            for xx in skin_lines:
                xFile.writelines(xx)

            xFile.close()
        except:
            self.session.open(MessageBox, _('Error by processing the skin file !!!'), MessageBox.TYPE_ERROR)

        restartbox = self.session.openWithCallback(self.restartGUI, MessageBox, _('GUI needs a restart to apply a new skin.\nDo you want to Restart the GUI now?'), MessageBox.TYPE_YESNO)
        restartbox.setTitle(_('Restart GUI now?'))

    def restartGUI(self, answer):
        if answer is True:
            self.session.open(TryQuitMainloop, 3)
        else:
            self.close()

    def checkforUpdate(self):
        try:
            fp = ''
            destr = '/tmp/aglareatvversion.txt'
            req = Request('https://raw.githubusercontent.com/popking159/skins/main/aglareatv/aglareatvversion.txt')
            req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36')
            fp = urlopen(req)
            fp = fp.read().decode('utf-8')
            print('fp read:', fp)
            with open(destr, 'w') as f:
                f.write(str(fp))  # .decode("utf-8"))
                f.seek(0)
                f.close()
            if os.path.exists(destr):
                with open(destr, 'r') as cc:
                    s1 = cc.readline()  # .decode("utf-8")
                    vers = s1.split('#')[0]
                    url = s1.split('#')[1]
                    version_server = vers.strip()
                    self.updateurl = url.strip()
                    cc.close()
                    if str(version_server) == str(versionaglare):
                        message = '%s %s\n%s %s\n\n%s' % (_('Server version:'),
                                                          version_server,
                                                          _('Version installed:'),
                                                          versionaglare,
                                                          _('You have the current version Aglare!'))
                        self.session.open(MessageBox, message, MessageBox.TYPE_INFO)
                    elif version_server > versionaglare:
                        message = '%s %s\n%s %s\n\n%s' % (_('Server version:'),
                                                          version_server,
                                                          _('Version installed:'),
                                                          versionaglare,
                                                          _('New update is available!\n\nDo you want to run the update now?'))
                        self.session.openWithCallback(self.update, MessageBox, message, MessageBox.TYPE_YESNO)
                    else:
                        self.session.open(MessageBox, _('You have version %s!!!') % versionaglare, MessageBox.TYPE_ERROR)
        except Exception as e:
            print('error: ', str(e))

    def retfile(self, dest):
        import requests
        response = requests.get(self.updateurl)
        if response.status_code == 200:
            with open(dest, 'wb') as f:
                f.write(response.content)
            print("File downloaded successfully")
            return True
        else:
            print("File download error")
        return False

    def update(self, answer):
        if answer:
            dest = "/tmp"
            if not os.path.exists(dest):
                os.system('ln -sf  /var/volatile/tmp /tmp')
            folddest = '/tmp/aglareatv.ipk'
            if self.retfile(folddest):
                cmd2 = "opkg install --force-reinstall --force-overwrite '/tmp/aglareatv.ipk"
                os.system(cmd2)
                os.system('sync')
                os.system('rm -r /tmp/aglareatv.ipk')
                os.system('sync')
                self.session.open(MessageBox, _('Aglare update was done!!!\nPlease restart the GUI to apply the changes!'), MessageBox.TYPE_INFO)
            else:
                self.session.open(MessageBox, _('Installing failure!'), MessageBox.TYPE_INFO)

    def keyExit(self):
        for x in self['config'].list:
            x[1].cancel()
        self.close()


_session = None
autoStartTimer = None


class AutoStartTimer:
    def __init__(self, session):
        print("*** running AutoStartTimer aglare ***")
        global _session
        self.session = session
        _session = session
        self.timer = eTimer()
        try:
            self.timer.callback.append(self.on_timer)
        except:
            self.timer_conn = self.timer.timeout.connect(self.on_timer)
        self.timer.start(100, True)
        self.update()

    def get_wake_time(self):
        if config.plugins.Aglare.autoupdate.value is True:
            if config.plugins.Aglare.timetype.value == "interval":
                interval = int(config.plugins.Aglare.updateinterval.value)
                nowt = time.time()
                return int(nowt) + interval * 60  # * 60
            if config.plugins.Aglare.timetype.value == "fixed time":
                ftc = config.plugins.Aglare.fixedtime.value
                now = time.localtime(time.time())
                fwt = int(time.mktime((now.tm_year,
                                       now.tm_mon,
                                       now.tm_mday,
                                       ftc[0],
                                       ftc[1],
                                       now.tm_sec,
                                       now.tm_wday,
                                       now.tm_yday,
                                       now.tm_isdst)))
                return fwt
        else:
            return -1

    def update(self, constant=0):
        self.timer.stop()
        wake = self.get_wake_time()
        nowt = time.time()
        if wake > 0:
            if wake < nowt + constant:
                if config.plugins.Aglare.timetype.value == "interval":
                    interval = int(config.plugins.Aglare.updateinterval.value)
                    wake += interval * 60  # * 60
                elif config.plugins.Aglare.timetype.value == "fixed time":
                    wake += 86400
            next = wake - int(nowt)
            if next > 3600:
                next = 3600
            if next <= 0:
                next = 60
            self.timer.startLongTimer(next)
        else:
            wake = -1
        return wake

    def on_timer(self):
        self.timer.stop()
        now = int(time.time())
        wake = now
        constant = 0
        if config.plugins.Aglare.timetype.value == "fixed time":
            wake = self.get_wake_time()
        if abs(wake - now) < 60:
            try:
                self.startMain()
                constant = 60
            except Exception as error:
                trace_error()
        self.update(constant)

    def startMain(self):
        print('start update check')
        try:
            fp = ''
            destr = '/tmp/aglareatvversion.txt'
            req = Request('https://raw.githubusercontent.com/popking159/skins/main/aglareatv/aglareatvversion.txt')
            req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36')
            fp = urlopen(req)
            fp = fp.read().decode('utf-8')
            print('fp read:', fp)
            with open(destr, 'w') as f:
                f.write(str(fp))  # .decode("utf-8"))
                f.seek(0)
                f.close()
            if os.path.exists(destr):
                with open(destr, 'r') as cc:
                    s1 = cc.readline()  # .decode("utf-8")
                    vers = s1.split('#')[0]
                    version_server = vers.strip()
                    cc.close()
                    if version_server > versionaglare:
                        import Tools.Notifications
                        from Screens.MessageBox import MessageBox
                        message = _('The update is available!\n\nPlease Upgrade Skin from plugin Aglare')
                        Tools.Notifications.AddNotification(MessageBox, message, MessageBox.TYPE_INFO, timeout=10)
                        print('The update is available!')
                    print('end update check')
        except Exception as e:
            print('error: ', str(e))


def autostart(reason, session=None, **kwargs):
    global autoStartTimer
    global _session
    if reason == 0 and _session is None:
        if session is not None:
            _session = session
            if autoStartTimer is None:
                autoStartTimer = AutoStartTimer(_session)
    return


# log
def trace_error():
    try:
        import traceback
        traceback.print_exc(file=sys.stdout)
        traceback.print_exc(file=open("/tmp/aglare.log", "a"))
    except:
        pass


def get_next_wakeup():
    return -1


def main(session, **kwargs):
    session.open(AglareSetup)


def Plugins(**kwargs):
    result = [PluginDescriptor(name="Setup Aglare", description=_('Customization tool for Aglare-FHD Skin'), where=[PluginDescriptor.WHERE_AUTOSTART, PluginDescriptor.WHERE_SESSIONSTART], fnc=autostart, wakeupfnc=get_next_wakeup),
              PluginDescriptor(name='Setup Aglare', description=_('Customization tool for Aglare-FHD Skin'), where=PluginDescriptor.WHERE_PLUGINMENU, icon='plugin.png', fnc=main)]
    return result
